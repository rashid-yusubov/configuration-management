#!/bin/bash

# Проверка наличия аргумента
if [ -z "$1" ]; then
  echo "Usage: $0 \"Your message here\""
  exit 1
fi

# Сообщение
message="$1"

# Длина сообщения
length=${#message}

# Верхняя граница
echo "+$(printf '%0.s-' $(seq 1 $((length + 2))))+"

# Сообщение с границами
echo "| $message |"

# Нижняя граница
echo "+$(printf '%0.s-' $(seq 1 $((length + 2))))+"
