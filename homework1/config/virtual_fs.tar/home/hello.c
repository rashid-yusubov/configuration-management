#include <stdio.h>

void main() {
    int hello = 1;
    printf("Hello, world!\n");
    return;
}
